/**
 * JPA domain objects.
 */
package com.pronix.sbc.domain;
