/**
 * Spring Security configuration.
 */
package com.pronix.sbc.security;
