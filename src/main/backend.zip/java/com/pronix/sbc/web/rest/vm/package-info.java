/**
 * View Models used by Spring MVC REST controllers.
 */
package com.pronix.sbc.web.rest.vm;
