/**
 * Data Access Objects used by WebSocket services.
 */
package com.pronix.sbc.web.websocket.dto;
