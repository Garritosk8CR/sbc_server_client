/**
 * Spring Data JPA repositories.
 */
package com.pronix.sbc.repository;
