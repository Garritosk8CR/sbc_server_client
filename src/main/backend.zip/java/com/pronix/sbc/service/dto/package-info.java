/**
 * Data Transfer Objects.
 */
package com.pronix.sbc.service.dto;
