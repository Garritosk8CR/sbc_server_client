/**
 * Service layer beans.
 */
package com.pronix.sbc.service;
